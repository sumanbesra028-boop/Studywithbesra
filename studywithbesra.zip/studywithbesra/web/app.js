const $ = s => document.querySelector(s);
const app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let user = JSON.parse(localStorage.getItem('besra') || 'null');

async function api(url, body) {
  const r = await fetch(url, body ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)} : {});
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Something went wrong.');
  return d;
}
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.style.display = 'block';
  clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 3500);
}
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message); } };

const views = {subjects: () => home(), planner: () => planner(), timer: () => timer()};
function header() {
  $('#who').innerHTML = user ? `${esc(user.name)} <button class="link" id="out">Switch learner</button>` : '';
  $('#nav').innerHTML = user ? [['subjects', 'Subjects'], ['planner', 'Study planner'], ['timer', 'Study timer']].map(([k, t]) => `<button data-v="${k}">${t}</button>`).join('') : '';
  $('#nav').querySelectorAll('button').forEach(b => b.onclick = guard(() => views[b.dataset.v]()));
  if (user) $('#out').onclick = () => { localStorage.removeItem('besra'); user = null; render(); };
}

async function planner() {
  const ts = await api('/api/tasks?learner=' + user.id);
  const today = new Date().toISOString().slice(0, 10);
  app.innerHTML = `<h2>Study planner</h2><p class="muted">Write down what you need to study and when it is due.</p>
    <form id="tf" class="row"><input id="tt" placeholder="e.g. Revise fractions" maxlength="120" required aria-label="Task">
    <input type="date" id="td" aria-label="Due date" style="width:auto"><button class="primary">Add task</button></form>` +
    (ts.length ? ts.map(t => {
      const late = !t.done && t.due_date && t.due_date < today;
      return `<div class="task"><label><input type="checkbox" data-t="${t.id}" ${t.done ? 'checked' : ''} style="width:auto"> <span class="${t.done ? 'strike' : ''}">${esc(t.title)}</span></label>
        <span class="${late ? 'wrong' : 'muted'}">${t.due_date ? (late ? 'Overdue: ' : 'Due ') + esc(t.due_date) : ''}</span>
        <button class="link" data-x="${t.id}">Delete</button></div>`;
    }).join('') : '<p class="muted">No tasks yet. Add your first one above.</p>');
  $('#tf').onsubmit = guard(async e => {
    e.preventDefault();
    await api('/api/tasks?learner=' + user.id, {title: $('#tt').value, due_date: $('#td').value}); await planner();
  });
  app.querySelectorAll('input[data-t]').forEach(c => c.onchange = guard(async () => { await api(`/api/tasks/${c.dataset.t}/toggle?learner=${user.id}`, {}); await planner(); }));
  app.querySelectorAll('button[data-x]').forEach(b => b.onclick = guard(async () => { await api(`/api/tasks/${b.dataset.x}/delete?learner=${user.id}`, {}); await planner(); }));
}

let tick = null;
async function timer() {
  clearInterval(tick); tick = null;
  const days = await api('/api/sessions?learner=' + user.id);
  const max = Math.max(30, ...days.map(d => +d.minutes)), total = days.reduce((s, d) => s + +d.minutes, 0);
  const fmt = s => String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  app.innerHTML = `<h2>Study timer</h2><p class="muted">Focus for a set time. Your minutes are saved when you finish.</p>
    <div class="score" id="clock">25:00</div>
    <div class="row"><input id="lab" placeholder="What are you studying?" maxlength="80" aria-label="What are you studying">
    <input id="mins" type="number" min="1" max="180" value="25" style="width:90px" aria-label="Minutes">
    <button class="primary" id="go">Start</button><button id="stop" hidden>Finish early</button></div>
    <h2 style="margin-top:28px;font-size:20px">Last 7 days: ${total} minutes</h2>` +
    days.map(d => `<div class="day"><span>${new Date(d.dt + 'T00:00:00').toLocaleDateString(undefined, {weekday: 'short'})}</span>
      <div class="bar"><i style="width:${Math.round(100 * d.minutes / max)}%"></i></div><span>${d.minutes} min</span></div>`).join('');
  $('#mins').oninput = () => { if (!tick) $('#clock').textContent = fmt((+$('#mins').value || 0) * 60); };
  $('#go').onclick = () => {
    const mins = +$('#mins').value;
    if (!(mins >= 1 && mins <= 180)) return toast('Choose between 1 and 180 minutes.');
    const start = Date.now(), end = start + mins * 60000;
    $('#go').disabled = true; $('#stop').hidden = false;
    const save = guard(async () => {
      clearInterval(tick); tick = null;
      const done = Math.min(mins, Math.floor((Date.now() - start) / 60000));
      if (done < 1) { toast('Less than a minute, so nothing was saved.'); return timer(); }
      await api('/api/sessions?learner=' + user.id, {minutes: done, label: $('#lab') ? $('#lab').value : ''});
      toast(`Saved ${done} minutes`); await timer();
    });
    $('#stop').onclick = save;
    tick = setInterval(() => {
      if (!$('#clock')) { clearInterval(tick); tick = null; return; }
      const left = Math.max(0, Math.round((end - Date.now()) / 1000));
      $('#clock').textContent = fmt(left);
      if (left === 0) save();
    }, 500);
  };
}

function login() {
  app.innerHTML = `<h2>Welcome</h2><p class="muted">Enter your name to start learning and keep track of your progress.</p>
    <form id="lf"><input id="name" placeholder="Your name" maxlength="60" required aria-label="Your name">
    <div class="row"><button class="primary">Start learning</button></div></form>`;
  $('#lf').onsubmit = guard(async e => {
    e.preventDefault();
    user = await api('/api/login', {name: $('#name').value});
    localStorage.setItem('besra', JSON.stringify(user)); render();
  });
}

async function home() {
  const subs = await api('/api/subjects?learner=' + user.id);
  app.innerHTML = `<h2>Your subjects</h2><p class="muted">Read each lesson, mark it done, then take the quiz.</p>` +
    subs.map(s => {
      const pct = s.lessons ? Math.round(100 * s.done / s.lessons) : 0;
      return `<div class="subject"><h3>${esc(s.title)}</h3><p class="muted">${esc(s.description)}</p>
        <div class="bar" role="img" aria-label="${pct}% of lessons done"><i style="width:${pct}%"></i></div>
        <div class="muted">${s.done} of ${s.lessons} lessons done${s.best !== null ? ` · best quiz score ${s.best}/${s.total}` : ''}</div>
        <div class="row"><button class="primary" data-s="${s.id}" data-t="${esc(s.title)}">Open ${esc(s.title)}</button></div></div>`;
    }).join('');
  app.querySelectorAll('button[data-s]').forEach(b => b.onclick = guard(() => subject(b.dataset.s, b.dataset.t)));
}

async function subject(id, title) {
  const ls = await api(`/api/subjects/${id}/lessons?learner=${user.id}`);
  app.innerHTML = `<button class="link" id="back">All subjects</button><h2>${esc(title)}</h2>` +
    ls.map(l => `<details><summary>${esc(l.title)}${l.done ? '<span class="tick">Done</span>' : ''}</summary>
      <p>${esc(l.content)}</p>${l.done ? '' : `<button data-l="${l.id}">Mark as done</button>`}</details>`).join('') +
    `<div class="row"><button class="primary" id="quiz">Take the quiz</button></div>`;
  $('#back').onclick = guard(home);
  $('#quiz').onclick = guard(() => quiz(id, title));
  app.querySelectorAll('button[data-l]').forEach(b => b.onclick = guard(async () => {
    await api(`/api/lessons/${b.dataset.l}/done?learner=${user.id}`, {learner: user.id}); toast('Lesson marked as done'); await subject(id, title);
  }));
}

async function quiz(id, title) {
  const qs = await api(`/api/subjects/${id}/quiz`);
  if (!qs.length) { toast('This subject has no quiz yet.'); return; }
  app.innerHTML = `<button class="link" id="back">Back to ${esc(title)}</button><h2>${esc(title)} quiz</h2><form id="qf">` +
    qs.map(q => `<fieldset class="q"><legend>${esc(q.text)}</legend>` +
      ['A','B','C','D'].map(k => `<label><input type="radio" name="q${q.id}" value="${k}" style="width:auto"> ${k}. ${esc(q['option_' + k.toLowerCase()])}</label>`).join('') + '</fieldset>').join('') +
    `<button class="primary">Submit answers</button></form><div id="res"></div>`;
  $('#back').onclick = guard(() => subject(id, title));
  $('#qf').onsubmit = guard(async e => {
    e.preventDefault();
    const answers = {};
    qs.forEach(q => { const c = e.target.querySelector(`input[name=q${q.id}]:checked`); if (c) answers[q.id] = c.value; });
    if (Object.keys(answers).length < qs.length) throw new Error('Answer every question before submitting.');
    const r = await api(`/api/subjects/${id}/quiz`, {learner: user.id, answers});
    $('#res').innerHTML = `<div class="score">${r.score} / ${r.total}</div>` + r.results.map((x, i) =>
      `<p class="${x.ok ? 'right' : 'wrong'}">Question ${i + 1}: ${x.ok ? 'Correct' : 'Incorrect, the answer is ' + x.correct}</p>`).join('');
    $('#qf button').disabled = true; $('#res').scrollIntoView();
  });
}

function render() { header(); user ? guard(home)() : login(); }
$('#home').onclick = e => { e.preventDefault(); if (user) guard(home)(); };
render();
