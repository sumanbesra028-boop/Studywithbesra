-- Run after schema.sql: adds the study planner and study timer tables
USE besra_db;

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  learner_id INT NOT NULL,
  title VARCHAR(120) NOT NULL,
  due_date DATE NULL,
  done BOOLEAN NOT NULL DEFAULT 0,
  FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE
);

CREATE TABLE study_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  learner_id INT NOT NULL,
  label VARCHAR(80),
  minutes INT NOT NULL,
  studied_on DATE NOT NULL,
  FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE
);
