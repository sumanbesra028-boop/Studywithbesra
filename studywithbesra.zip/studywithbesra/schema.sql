CREATE DATABASE IF NOT EXISTS besra_db CHARACTER SET utf8mb4;
USE besra_db;

CREATE TABLE learners (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL UNIQUE);
CREATE TABLE subjects (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(80) NOT NULL, description VARCHAR(200));
CREATE TABLE lessons (
  id INT AUTO_INCREMENT PRIMARY KEY, subject_id INT NOT NULL, position INT NOT NULL,
  title VARCHAR(120) NOT NULL, content TEXT NOT NULL,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE);
CREATE TABLE questions (
  id INT AUTO_INCREMENT PRIMARY KEY, subject_id INT NOT NULL, text VARCHAR(255) NOT NULL,
  option_a VARCHAR(120) NOT NULL, option_b VARCHAR(120) NOT NULL, option_c VARCHAR(120) NOT NULL, option_d VARCHAR(120) NOT NULL,
  correct CHAR(1) NOT NULL,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE);
CREATE TABLE lesson_progress (
  learner_id INT NOT NULL, lesson_id INT NOT NULL, done_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (learner_id, lesson_id),
  FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE,
  FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE);
CREATE TABLE quiz_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY, learner_id INT NOT NULL, subject_id INT NOT NULL,
  score INT NOT NULL, total INT NOT NULL, taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (learner_id) REFERENCES learners(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE);

-- Sample content: replace with your own
INSERT INTO subjects (title, description) VALUES
 ('Mathematics', 'Fractions and percentages made simple.'),
 ('Science', 'How plants and water work.'),
 ('English', 'Parts of speech and sentence building.');

INSERT INTO lessons (subject_id, position, title, content) VALUES
 (1, 1, 'What is a fraction?', 'A fraction shows part of a whole. In 3/4, the 4 is the denominator (equal parts) and the 3 is the numerator (parts we take).\n\nTo compare fractions with the same denominator, compare the numerators.'),
 (1, 2, 'Percentages', 'Percent means "out of 100". 25% is the same as 25/100, which simplifies to 1/4.\n\nTo find 10% of a number, divide it by 10.'),
 (2, 1, 'Photosynthesis', 'Plants make their own food using sunlight, water and carbon dioxide. This happens in the leaves, inside chloroplasts.\n\nThe plant releases oxygen as a by-product.'),
 (2, 2, 'The water cycle', 'Water evaporates from oceans and lakes, condenses into clouds, falls as precipitation, and flows back to the sea.'),
 (3, 1, 'Nouns and verbs', 'A noun names a person, place or thing. A verb tells what someone does or is.\n\nIn "Besra reads books", Besra and books are nouns, and reads is the verb.'),
 (3, 2, 'Adjectives', 'An adjective describes a noun: a tall tree, a quiet room. It usually comes before the noun it describes.');

INSERT INTO questions (subject_id, text, option_a, option_b, option_c, option_d, correct) VALUES
 (1, 'In 3/4, what is the denominator?', '3', '4', '7', '1', 'B'),
 (1, 'What is 10% of 250?', '10', '15', '25', '100', 'C'),
 (1, '25% is the same fraction as', '1/2', '1/3', '1/4', '2/5', 'C'),
 (2, 'Which gas do plants release during photosynthesis?', 'Oxygen', 'Nitrogen', 'Hydrogen', 'Methane', 'A'),
 (2, 'Where does photosynthesis mainly happen?', 'Roots', 'Leaves', 'Stem', 'Seeds', 'B'),
 (3, 'Which word is a verb in "Besra reads books"?', 'Besra', 'reads', 'books', 'None', 'B'),
 (3, 'Which word is an adjective in "a quiet room"?', 'a', 'quiet', 'room', 'None', 'B');
