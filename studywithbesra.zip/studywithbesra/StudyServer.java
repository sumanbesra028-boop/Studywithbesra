import com.sun.net.httpserver.*;
import java.io.*;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

@SuppressWarnings("unchecked")
public class StudyServer {
  static String env(String k, String d) { String v = System.getenv(k); return v == null ? d : v; }
  static final String URL = env("DB_URL", "jdbc:mysql://localhost:3306/besra_db?serverTimezone=Asia/Kolkata&allowPublicKeyRetrieval=true&useSSL=false");
  static final String USER = env("DB_USER", "root"), PASS = env("DB_PASS", "");
  static final Path WEB = Paths.get("web").toAbsolutePath();

  public static void main(String[] a) throws Exception {
    HttpServer s = HttpServer.create(new InetSocketAddress(8080), 0);
    s.createContext("/api", StudyServer::api);
    s.createContext("/", StudyServer::file);
    s.start();
    System.out.println("Open http://localhost:8080");
  }

  static void api(HttpExchange ex) throws IOException {
    int code = 200; Object out;
    try (Connection c = DriverManager.getConnection(URL, USER, PASS)) {
      String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
      out = route(c, ex.getRequestURI().getPath().split("/"), query(ex.getRequestURI().getRawQuery()), body);
    } catch (IllegalArgumentException e) { code = 400; out = Map.of("error", String.valueOf(e.getMessage()));
    } catch (Exception e) { e.printStackTrace(); code = 500; out = Map.of("error", "Server error. Please try again."); }
    byte[] b = Json.write(out).getBytes(StandardCharsets.UTF_8);
    ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
    ex.sendResponseHeaders(code, b.length);
    try (OutputStream o = ex.getResponseBody()) { o.write(b); }
  }

  static Object route(Connection c, String[] p, Map<String,String> q, String body) throws Exception {
    String r = p.length > 2 ? p[2] : "";
    long me = Long.parseLong(q.getOrDefault("learner", "0"));

    if (r.equals("login")) {
      String n = String.valueOf(((Map<String,Object>) Json.parse(body)).get("name")).trim();
      if (n.isEmpty() || n.equals("null") || n.length() > 60) throw new IllegalArgumentException("Enter your name (up to 60 characters).");
      run(c, "INSERT IGNORE INTO learners (name) VALUES (?)", n);
      return rows(c, "SELECT id, name FROM learners WHERE name=?", n).get(0);
    }
    if (r.equals("subjects") && p.length == 3)
      return rows(c, "SELECT s.id, s.title, s.description,"
        + " (SELECT COUNT(*) FROM lessons WHERE subject_id=s.id) lessons,"
        + " (SELECT COUNT(*) FROM lesson_progress lp JOIN lessons l ON l.id=lp.lesson_id WHERE l.subject_id=s.id AND lp.learner_id=?) done,"
        + " (SELECT COUNT(*) FROM questions WHERE subject_id=s.id) total,"
        + " (SELECT MAX(score) FROM quiz_attempts WHERE subject_id=s.id AND learner_id=?) best"
        + " FROM subjects s ORDER BY s.id", me, me);
    if (r.equals("subjects") && p.length == 5) {
      long sid = Long.parseLong(p[3]);
      if (p[4].equals("lessons"))
        return rows(c, "SELECT l.id, l.title, l.content, (lp.lesson_id IS NOT NULL) done FROM lessons l"
          + " LEFT JOIN lesson_progress lp ON lp.lesson_id=l.id AND lp.learner_id=? WHERE l.subject_id=? ORDER BY l.position", me, sid);
      if (p[4].equals("quiz") && body.isEmpty())
        return rows(c, "SELECT id, text, option_a, option_b, option_c, option_d FROM questions WHERE subject_id=? ORDER BY id", sid);
      if (p[4].equals("quiz")) { // submit answers
        Map<String,Object> b = (Map<String,Object>) Json.parse(body);
        Map<String,Object> ans = (Map<String,Object>) b.get("answers");
        long who = Long.parseLong(String.valueOf(b.get("learner")));
        int score = 0; List<Map<String,Object>> res = new ArrayList<>();
        List<Map<String,Object>> qs = rows(c, "SELECT id, correct FROM questions WHERE subject_id=? ORDER BY id", sid);
        for (Map<String,Object> qq : qs) {
          Object given = ans == null ? null : ans.get(String.valueOf(qq.get("id")));
          boolean ok = qq.get("correct").equals(given); if (ok) score++;
          res.add(Map.of("id", qq.get("id"), "correct", qq.get("correct"), "ok", ok));
        }
        run(c, "INSERT INTO quiz_attempts (learner_id, subject_id, score, total) VALUES (?,?,?,?)", who, sid, score, qs.size());
        return Map.of("score", score, "total", qs.size(), "results", res);
      }
    }
    if (r.equals("lessons") && p.length == 5 && p[4].equals("done")) {
      long who = Long.parseLong(String.valueOf(((Map<String,Object>) Json.parse(body)).get("learner")));
      run(c, "INSERT IGNORE INTO lesson_progress (learner_id, lesson_id) VALUES (?,?)", who, Long.parseLong(p[3]));
      return Map.of("ok", true);
    }
    if (r.equals("tasks")) {
      if (p.length == 3 && body.isEmpty())
        return rows(c, "SELECT id, title, due_date, done FROM tasks WHERE learner_id=? ORDER BY done, due_date IS NULL, due_date, id", me);
      if (p.length == 3) {
        Map<String,Object> b = (Map<String,Object>) Json.parse(body);
        String t = String.valueOf(b.get("title")).trim(), d = String.valueOf(b.get("due_date")).trim();
        if (t.isEmpty() || t.equals("null") || t.length() > 120) throw new IllegalArgumentException("Enter a task (up to 120 characters).");
        run(c, "INSERT INTO tasks (learner_id, title, due_date) VALUES (?,?,?)", me, t, d.isEmpty() || d.equals("null") ? null : d);
        return Map.of("ok", true);
      }
      run(c, p[4].equals("delete") ? "DELETE FROM tasks WHERE id=? AND learner_id=?" : "UPDATE tasks SET done = 1 - done WHERE id=? AND learner_id=?", Long.parseLong(p[3]), me);
      return Map.of("ok", true);
    }
    if (r.equals("sessions")) {
      if (body.isEmpty()) // minutes studied on each of the last 7 days
        return rows(c, "SELECT d.dt, COALESCE(SUM(s.minutes),0) minutes FROM (SELECT CURDATE() - INTERVAL n DAY dt FROM"
          + " (SELECT 0 n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6) x) d"
          + " LEFT JOIN study_sessions s ON s.studied_on=d.dt AND s.learner_id=? GROUP BY d.dt ORDER BY d.dt", me);
      Map<String,Object> b = (Map<String,Object>) Json.parse(body);
      int mins = Integer.parseInt(String.valueOf(b.get("minutes")));
      if (mins < 1 || mins > 600) throw new IllegalArgumentException("Minutes must be between 1 and 600.");
      String label = String.valueOf(b.getOrDefault("label", "")).trim();
      run(c, "INSERT INTO study_sessions (learner_id, label, minutes, studied_on) VALUES (?,?,?,CURDATE())", me, label.length() > 80 ? label.substring(0, 80) : label, mins);
      return Map.of("ok", true);
    }
    throw new IllegalArgumentException("Unknown request.");
  }

  static void run(Connection c, String sql, Object... a) throws SQLException {
    try (PreparedStatement ps = c.prepareStatement(sql)) { for (int i = 0; i < a.length; i++) ps.setObject(i + 1, a[i]); ps.executeUpdate(); }
  }

  static List<Map<String,Object>> rows(Connection c, String sql, Object... a) throws SQLException {
    List<Map<String,Object>> out = new ArrayList<>();
    try (PreparedStatement ps = c.prepareStatement(sql)) {
      for (int i = 0; i < a.length; i++) ps.setObject(i + 1, a[i]);
      ResultSet r = ps.executeQuery(); ResultSetMetaData md = r.getMetaData();
      while (r.next()) { Map<String,Object> row = new LinkedHashMap<>(); for (int i = 1; i <= md.getColumnCount(); i++) row.put(md.getColumnLabel(i), r.getObject(i)); out.add(row); }
    }
    return out;
  }

  static Map<String,String> query(String raw) {
    Map<String,String> m = new HashMap<>();
    if (raw != null) for (String kv : raw.split("&")) { String[] p = kv.split("=", 2); m.put(URLDecoder.decode(p[0], StandardCharsets.UTF_8), p.length > 1 ? URLDecoder.decode(p[1], StandardCharsets.UTF_8) : ""); }
    return m;
  }

  static void file(HttpExchange ex) throws IOException {
    String path = ex.getRequestURI().getPath(); if (path.equals("/")) path = "/index.html";
    Path f = WEB.resolve(path.substring(1)).normalize();
    if (!f.startsWith(WEB) || !Files.isRegularFile(f)) { ex.sendResponseHeaders(404, -1); ex.close(); return; }
    String n = f.toString();
    ex.getResponseHeaders().set("Content-Type", n.endsWith(".html") ? "text/html; charset=utf-8" : n.endsWith(".css") ? "text/css" : "text/javascript");
    byte[] b = Files.readAllBytes(f);
    ex.sendResponseHeaders(200, b.length);
    try (OutputStream o = ex.getResponseBody()) { o.write(b); }
  }

  // Minimal JSON reader/writer so only the MySQL driver is needed.
  static class Json {
    String s; int i;
    static Object parse(String t) {
      try { Json j = new Json(); j.s = t; return j.val(); } catch (RuntimeException e) { throw new IllegalArgumentException("Invalid request."); }
    }
    void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    Object val() {
      ws(); char c = s.charAt(i);
      if (c == '{') { i++; Map<String,Object> m = new LinkedHashMap<>(); ws(); if (s.charAt(i) == '}') { i++; return m; }
        while (true) { ws(); String k = str(); ws(); i++; m.put(k, val()); ws(); if (s.charAt(i++) == '}') return m; } }
      if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws(); if (s.charAt(i) == ']') { i++; return l; }
        while (true) { l.add(val()); ws(); if (s.charAt(i++) == ']') return l; } }
      if (c == '"') return str();
      if (s.startsWith("true", i)) { i += 4; return true; }
      if (s.startsWith("false", i)) { i += 5; return false; }
      if (s.startsWith("null", i)) { i += 4; return null; }
      int st = i; while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
      return new BigDecimal(s.substring(st, i));
    }
    String str() {
      i++; StringBuilder b = new StringBuilder();
      while (s.charAt(i) != '"') {
        char c = s.charAt(i++);
        if (c != '\\') { b.append(c); continue; }
        char n = s.charAt(i++);
        if (n == 'n') b.append('\n'); else if (n == 't') b.append('\t');
        else if (n == 'u') { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; } else b.append(n);
      }
      i++; return b.toString();
    }
    static String write(Object o) {
      if (o == null) return "null";
      if (o instanceof BigDecimal) return ((BigDecimal) o).toPlainString();
      if (o instanceof Number || o instanceof Boolean) return o.toString();
      StringBuilder b = new StringBuilder();
      if (o instanceof Map) { b.append('{'); boolean f = true;
        for (Map.Entry<?,?> e : ((Map<?,?>) o).entrySet()) { if (!f) b.append(','); f = false; b.append(quote(e.getKey().toString())).append(':').append(write(e.getValue())); }
        return b.append('}').toString(); }
      if (o instanceof List) { b.append('['); boolean f = true;
        for (Object x : (List<?>) o) { if (!f) b.append(','); f = false; b.append(write(x)); }
        return b.append(']').toString(); }
      return quote(o.toString());
    }
    static String quote(String s) {
      StringBuilder b = new StringBuilder("\"");
      for (char c : s.toCharArray()) {
        if (c == '"') b.append("\\\""); else if (c == '\\') b.append("\\\\"); else if (c == '\n') b.append("\\n");
        else if (c < 32) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
      }
      return b.append('"').toString();
    }
  }
}
